package com.example.ordermanager.service;/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */

import com.example.ordermanager.entity.Order;
import com.example.ordermanager.entity.StockMovement;
import com.example.ordermanager.repository.OrderRepository;
import com.example.ordermanager.repository.StockMovementRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
/**
 * Service class for managing stock movements.
 */
@Service
public class StockMovementService {
    private final StockMovementRepository stockMovementRepository;
    private final OrderRepository orderRepository;

    private static final Logger logger = LogManager.getLogger(StockMovementService.class);

    @Autowired
    public StockMovementService(
            StockMovementRepository stockMovementRepository,
            OrderRepository orderRepository) {
        this.stockMovementRepository = stockMovementRepository;
        this.orderRepository = orderRepository;
    }

    public List<StockMovement> getAllStockMovements() {
        List<StockMovement> stockMovements = stockMovementRepository.findAll();
        logger.info("Retrieved all stock movements: " + stockMovements);
        return stockMovements;
    }

    public StockMovement getStockMovementById(Long stockMovementId) {
        return stockMovementRepository.findById(stockMovementId).orElse(null);
    }

    public StockMovement saveStock(StockMovement stockMovement) {
        List<Order> incompleteOrders = orderRepository.findByCompletedFalse();

        if (!incompleteOrders.isEmpty()) {
            Order order = incompleteOrders.get(0);
            stockMovement.setOrder(order);
            stockMovementRepository.save(stockMovement);
            logger.info("Stock movement saved and linked to an incomplete order. Stock Movement ID: {}, Order ID: {}",
                    stockMovement.getId(), order.getId());
        } else {
            logger.warn("No incomplete orders found. Stock movement creation failed. Stock Movement ID: {}",
                    stockMovement.getId());
        }

        return stockMovement;
    }

    public void deleteStockMovement(Long stockMovementId) {
        if (stockMovementRepository.existsById(stockMovementId)) {
            stockMovementRepository.deleteById(stockMovementId);
            logger.info("Deleted stock movement with ID: " + stockMovementId);
        } else {
            logger.warn("Stock movement with ID " + stockMovementId + " not found. Deletion failed.");
        }
    }

    public StockMovement updateStockMovement(Long stockMovementId, StockMovement updatedStockMovement) {
        if (stockMovementRepository.existsById(stockMovementId)) {
            updatedStockMovement.setId(stockMovementId); // Ensure the ID of the updated stock movement is set
            StockMovement updated = stockMovementRepository.save(updatedStockMovement);
            logger.info("Updated stock movement with ID " + stockMovementId + ": " + updated);
            return updated;
        } else {
            logger.warn("Stock movement with ID " + stockMovementId + " not found. Update failed.");
            return null;
        }
    }
}
