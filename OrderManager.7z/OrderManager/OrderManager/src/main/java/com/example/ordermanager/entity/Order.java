package com.example.ordermanager.entity;
/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */

/**
 * com.example.ordermanager.entity.Order class
 *
 * @author S0134948-Edson Antunes on 09/03/2024
 */

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "orders")
@Getter
@Setter
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime creationDate;

    @ManyToOne
    @JoinColumn(name = "item_id", referencedColumnName = "id")
    private Item item;

    private int quantity;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;
    @Column(name = "completed")
    private boolean completed;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    private List<StockMovement> stockMovements;
    public Order() {
        // Default constructor for JPA
    }

    public Order(LocalDateTime creationDate, Item item, int quantity, User user) {
        this.creationDate = creationDate;
        this.item = item;
        this.quantity = quantity;
        this.user = user;
        this.completed = false; // Orders are initially not completed
    }
}