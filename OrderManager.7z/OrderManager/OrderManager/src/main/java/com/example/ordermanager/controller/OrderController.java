
/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */
package com.example.ordermanager.controller;

import com.example.ordermanager.controller.request.OrderRequest;
import com.example.ordermanager.entity.Item;
import com.example.ordermanager.entity.Order;
import com.example.ordermanager.entity.StockMovement;
import com.example.ordermanager.entity.User;
import com.example.ordermanager.service.ItemService;
import com.example.ordermanager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.ordermanager.service.OrderService;

import java.util.List;
import java.util.Optional;

/**
 * OrderController class
 *
 * @author S0134948-Edson Antunes on 09/03/2024
 */
@RestController
@RequestMapping("/orders")
public class OrderController {
    private final OrderService orderService;
    private final UserService userService;
    private final ItemService itemService;

    @Autowired
    public OrderController(OrderService orderService, UserService userService, ItemService itemService) {
        this.orderService = orderService;
        this.userService = userService;
        this.itemService = itemService;

    }

    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequest orderRequest) {
        // Fetch the User from the database using the provided userId
        Optional<User> optionalUser = userService.getUserById(orderRequest.getUserId());
        User user = optionalUser.orElse(null);

        if (user == null) {
            // If the user is not found, return a bad request response
            return ResponseEntity.badRequest().build();
        }

        // Fetch the Item from the database using the provided itemId
        Item item = itemService.getItemById(orderRequest.getItemId());

        if (item == null) {
            // If the item is not found, return a bad request response
            return ResponseEntity.badRequest().build();
        }

        // Create the Order object with the fetched User and Item
        Order order = new Order(orderRequest.getCreationDate(), item, orderRequest.getQuantity(), user);

        // Save the Order
        Order createdOrder = orderService.saveOrder(order);

        if (createdOrder != null) {
            // Try to satisfy the order
            orderService.tryToSatisfyOrder(createdOrder);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdOrder);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<Order> readOrderById(@PathVariable Long orderId) {
        Order order = orderService.getOrderById(orderId);

        if (order == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(order);
    }

    @PutMapping("/{orderId}")
    public ResponseEntity<Order> updateOrder(@PathVariable Long orderId, @RequestBody Order updatedOrder) {
        Order existingOrder = orderService.getOrderById(orderId);

        if (existingOrder == null) {
            return ResponseEntity.notFound().build();
        }

        updatedOrder.setId(orderId);
        Order savedOrder = orderService.saveOrder(updatedOrder);
        return ResponseEntity.ok(savedOrder);
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity<Void> deleteOrder(@PathVariable Long orderId) {
        Order existingOrder = orderService.getOrderById(orderId);

        if (existingOrder == null) {
            return ResponseEntity.notFound().build();
        }

        orderService.deleteOrder(orderId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/{orderId}/stockMovements")
    public ResponseEntity<List<StockMovement>> getStockMovementsForOrder(@PathVariable Long orderId) {
        Order order = orderService.getOrderById(orderId);

        if (order == null) {
            return ResponseEntity.notFound().build();
        }

        List<StockMovement> stockMovements = order.getStockMovements();
        return ResponseEntity.ok(stockMovements);
    }
}
