package com.example.ordermanager.service;/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */

import com.example.ordermanager.entity.Order;
import com.example.ordermanager.entity.StockMovement;
import com.example.ordermanager.repository.OrderRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class OrderService {
    private static final Logger logger = LogManager.getLogger(OrderService.class);
    private final OrderRepository orderRepository;
    private final StockMovementService stockMovementService;

    @Autowired
    public OrderService(OrderRepository orderRepository, StockMovementService stockMovementService) {
        this.orderRepository = orderRepository;
        this.stockMovementService = stockMovementService;
    }

    public Order getOrderById(Long orderId) {
        return orderRepository.findById(orderId).orElse(null);
    }

    public Order saveOrder(Order order) {
        return orderRepository.save(order);
    }

    public List<Order> getIncompleteOrders() {
        return orderRepository.findByCompletedFalse();
    }

    public void updateOrder(Order order) {
        if (order.getQuantity() == 0) {
            order.setCompleted(true);
            orderRepository.save(order);

            logger.info("Sending email to: {} - Your order has been fulfilled.", order.getUser().getEmail());

            logger.info("Order fulfilled successfully. Order ID: {}, Completed: {}, Quantity: {}, Email sent to: {}",
                    order.getId(), order.isCompleted(), order.getQuantity(), order.getUser().getEmail());
        } else {
            logger.warn("Order fulfillment failed. Order ID: {}, Remaining Quantity: {}",
                    order.getId(), order.getQuantity());
        }
    }

    public void tryToSatisfyOrder(Order order) {
        try {
            if (order != null && order.getQuantity() > 0) {
                order.setCompleted(true);
                orderRepository.save(order);

                // Simulate sending an email notification
                logger.info("Sending email to: {} - Your order has been fulfilled.", order.getUser().getEmail());

                // Log completed order, stock movements, and email sent
                logger.info("Order fulfilled successfully. Order ID: {}, Completed: {}, Quantity: {}, Email sent to: {}",
                        order.getId(), order.isCompleted(), order.getQuantity(), order.getUser().getEmail());

                // Update stock movements
                StockMovement stockMovement = new StockMovement();
                stockMovement.setQuantity(order.getQuantity());
                stockMovementService.saveStock(stockMovement);
            } else {
                if (order == null) {
                    logger.warn("Order is null. Unable to fulfill order.");
                } else {
                    logger.warn("Order fulfillment failed. Order ID: {}, Remaining Quantity: {}",
                            order.getId(), order.getQuantity());
                }
            }
        } catch (Exception e) {
            logger.error("An error occurred while processing the order.", e);
        }
    }

    public void deleteOrder(Long orderId) {
        orderRepository.deleteById(orderId);
        logger.info("Order deleted successfully. Order ID: {}", orderId);
    }

    public List<StockMovement> getStockMovementsForOrder(Long orderId) {
        Order order = getOrderById(orderId);

        if (order != null) {
            return order.getStockMovements();
        } else {
            logger.warn("Order with ID {} not found. Unable to retrieve stock movements.", orderId);
            return Collections.emptyList();
        }
    }

    public Map<Long, Integer> getCurrentOrderCompletions() {
        List<Order> allOrders = orderRepository.findAll();
        Map<Long, Integer> orderCompletions = new HashMap<>();

        for (Order order : allOrders) {
            orderCompletions.put(order.getId(), order.getQuantity());
        }

        return orderCompletions;
    }
}

