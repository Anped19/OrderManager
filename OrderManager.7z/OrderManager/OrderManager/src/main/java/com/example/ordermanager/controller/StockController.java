
/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */
package com.example.ordermanager.controller;

import com.example.ordermanager.entity.Order;
import com.example.ordermanager.entity.StockMovement;
import com.example.ordermanager.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.ordermanager.service.StockMovementService;

import java.util.List;

/**
 * StockMovementController class
 *
 * @author S0134948-Edson Antunes on 09/03/2024
 */

@RestController
@RequestMapping("/stocks")
public class StockController {
    private final StockMovementService stockMovementService;
    private final OrderService orderService;

    @Autowired
    public StockController(StockMovementService stockMovementService, OrderService orderService) {
        this.stockMovementService = stockMovementService;
        this.orderService = orderService;
    }

    @GetMapping("/{stockId}")
    public ResponseEntity<StockMovement> getStockMovementById(@PathVariable Long stockId) {
        StockMovement stockMovement = stockMovementService.getStockMovementById(stockId);

        if (stockMovement == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(stockMovement);
    }

    @PutMapping("/{stockId}")
    public ResponseEntity<StockMovement> updateStockMovement(
            @PathVariable Long stockId, @RequestBody StockMovement updatedStockMovement) {
        StockMovement existingStockMovement = stockMovementService.getStockMovementById(stockId);

        if (existingStockMovement == null) {
            return ResponseEntity.notFound().build();
        }

        updatedStockMovement.setId(stockId);
        StockMovement savedStockMovement = stockMovementService.saveStock(updatedStockMovement);
        return ResponseEntity.ok(savedStockMovement);
    }

    @DeleteMapping("/{stockId}")
    public ResponseEntity<Void> deleteStockMovement(@PathVariable Long stockId) {
        StockMovement existingStockMovement = stockMovementService.getStockMovementById(stockId);

        if (existingStockMovement == null) {
            return ResponseEntity.notFound().build();
        }

        stockMovementService.deleteStockMovement(stockId);
        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<StockMovement> createStockMovement(@RequestBody StockMovement stockMovement) {

            List<Order> incompleteOrders = orderService.getIncompleteOrders();

            if (!incompleteOrders.isEmpty()) {
                Order order = incompleteOrders.get(0); // Choose the first incomplete order for simplicity
                stockMovement.setOrder(order);
                StockMovement createdStockMovement = stockMovementService.saveStock(stockMovement);
                return ResponseEntity.status(HttpStatus.CREATED).body(createdStockMovement);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }

    }
}
