package com.example.ordermanager.service;/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */

import com.example.ordermanager.entity.Item;
import com.example.ordermanager.repository.ItemRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemService {
    private final ItemRepository itemRepository;
    private static final Logger logger = LogManager.getLogger(ItemRepository.class);

    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public Item saveItem(Item item) {
        Item createdItem = itemRepository.save(item);
        logger.info("Saved item: " + createdItem);
        return createdItem;
    }

    public List<Item> getAllItems() {
        List<Item> items = itemRepository.findAll();
        logger.info("Retrieved items: " + items);
        return items;
    }

    public Item getItemById(Long itemId) {
        return itemRepository.findById(itemId).orElse(null);
    }

    public void deleteItem(Long itemId) {
        if (itemRepository.existsById(itemId)) {
            itemRepository.deleteById(itemId);
            logger.info("Deleted item with ID: " + itemId);
        } else {
            logger.warn("Item with ID " + itemId + " not found. Deletion failed.");
        }
    }

    public Item updateItem(Long itemId, Item updatedItem) {
        if (itemRepository.existsById(itemId)) {
            updatedItem.setId(itemId);
            Item updated = itemRepository.save(updatedItem);
            logger.info("Updated item with ID " + itemId + ": " + updated);
            return updated;
        } else {
            logger.warn("Item with ID " + itemId + " not found. Update failed.");
            return null;
        }
    }
}
