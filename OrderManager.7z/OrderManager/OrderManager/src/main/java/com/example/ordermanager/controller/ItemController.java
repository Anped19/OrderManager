
/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */
package com.example.ordermanager.controller;

import com.example.ordermanager.entity.Item;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.ordermanager.service.ItemService;

import java.util.List;

/**
 * ItemController class
 *
 * @author S0134948-Edson Antunes on 09/03/2024
 */

@RestController
@RequestMapping("/items")
public class ItemController {
    private final ItemService itemService;
    private static final Logger logger = LogManager.getLogger(ItemController.class);

    @Autowired
    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @PostMapping
    public Item createItem(@RequestBody Item item) {
        Item createdItem = itemService.saveItem(item);
        logger.info("Created item: " + createdItem);
        return createdItem;
    }

    @GetMapping
    public List<Item> readAllItems() {
        return itemService.getAllItems();
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> readItemById(@PathVariable Long itemId) {
        Item item = itemService.getItemById(itemId);
        if (item != null) {
            return ResponseEntity.ok(item);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable Long itemId, @RequestBody Item updatedItem) {
        Item existingItem = itemService.getItemById(itemId);

        if (existingItem != null) {
            updatedItem.setId(itemId);
            Item savedItem = itemService.saveItem(updatedItem);
            logger.info("Updated item: " + savedItem);
            return ResponseEntity.ok(savedItem);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long itemId) {
        Item existingItem = itemService.getItemById(itemId);

        if (existingItem != null) {
            itemService.deleteItem(itemId);
            logger.info("Deleted item with ID: " + itemId);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
