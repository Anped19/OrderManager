package com.example.ordermanager.entity;
/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */

/**
 * com.example.ordermanager.entity.Item class
 *
 * @author S0134948-Edson Antunes on 09/03/2024
 */


import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "item_order")
@Getter
@Setter
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    public Item() {
        // Default constructor
    }


}