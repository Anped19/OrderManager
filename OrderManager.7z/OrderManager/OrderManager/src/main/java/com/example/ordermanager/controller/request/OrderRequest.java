
/*

 * Copyright (c) Thales Air Systems SA 2014-2024 all rights reserved.

 * This software is the property of Thales Air Systems SA

 * and may not be used in any manner

 * except under a license agreement signed with Thales Air Systems SA.

 */
package com.example.ordermanager.controller.request;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * OrderRequest class
 *
 * @author S0134948-Edson Antunes on 11/03/2024
 */
@Getter
@Setter
public class OrderRequest {
    private LocalDateTime creationDate;
    private Long itemId;
    private int quantity;
    private Long userId;
}